# samsung-dex-standalone-mode

Magisk module to systemlessly enable Samsung DeX standalone mode by patching `floating_feature.xml`, adds `standalone` value to the key `<SEC_FLOATING_FEATURE_COMMON_CONFIG_DEX_MODE>`.




